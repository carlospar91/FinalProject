package com.example.finalproject3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;
import android.view.View;
import android.widget.Button;


import java.net.URI;

public class Activity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_5);
    }

    public void eBook(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://uhdowntown-my.sharepoint.com/:b:/g/personal/patinoc6_gator_uhd_edu/EZ9890vc1ZJNuFHdRdL0fcwB6euMd24nK_14Xjxd3A7S4A?e=cS0jgh"));
        startActivity(C);

    }

    public void Additional(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.microsoft.com/express/product/"));
        startActivity(C);
    }

    public void Video(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=vLnPwxZdW4Y"));
        startActivity(C);

    }

    public void Tutorial(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tutorialspoint.com/cplusplus/index.htm"));
        startActivity(C);

    }

    public void rateProf(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ratemyprofessors.com/campusRatings.jsp?sid=4134"));
        startActivity(C);

    }

    public void quizzes(View view){
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://quizlet.com/257765189/c-flash-cards/"));
        startActivity(C);

    }

    public void browser1(View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.uhd.edu/myuhd/Pages/Student-Login.aspx"));
        startActivity(browserIntent);
    }

    public void feedback(View view){
        Intent Open6Intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://docs.google.com/forms/d/e/1FAIpQLSe1IqRWZKl9tPNaJhCl0Fpl8mJgpUSwtREJPqNfo34eeoFrqQ/viewform?vc=0&c=0&w=1"));
        startActivity(Open6Intent);

    }

    public void home(View view){
        Intent browserIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(browserIntent);

    }

}

