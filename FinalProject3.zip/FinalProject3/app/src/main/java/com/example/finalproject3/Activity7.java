package com.example.finalproject3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class Activity7 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_7);
    }

    public void eBook(View view) {
        Intent Digital = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bkstr.com/houstondowntownstore/shop/textbooks-and-course-materials"));
        startActivity(Digital);

    }
    public void Additional(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://tutorialspoint.dev/computer-science/digital-electronics-and-logic-design"));
        startActivity(C);
    }

    public void Video(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=sPq7JgxL3h0"));
        startActivity(C);

    }

    public void Tutorial(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://gradeup.co/computer-science-engineering/digital-logic"));
        startActivity(C);

    }

    public void quizzes(View view){
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://quizlet.com/88911036/digital-logic-fundamentals-terms-flash-cards/"));
        startActivity(C);

    }


    public void browser1(View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.uhd.edu/myuhd/Pages/Student-Login.aspx"));
        startActivity(browserIntent);
    }

    public void feedback(View view){
        Intent Open6Intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://docs.google.com/forms/d/e/1FAIpQLSe1IqRWZKl9tPNaJhCl0Fpl8mJgpUSwtREJPqNfo34eeoFrqQ/viewform?vc=0&c=0&w=1"));
        startActivity(Open6Intent);

    }

    public void home(View view){
        Intent browserIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(browserIntent);

    }

}