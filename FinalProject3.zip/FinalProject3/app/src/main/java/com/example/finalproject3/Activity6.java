package com.example.finalproject3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class Activity6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_6);
    }

    public void eBook(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bkstr.com/houstondowntownstore/shop/textbooks-and-course-materials"));
        startActivity(C);

    }

    public void Video(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=computer+organization"));
        startActivity(C);

    }

    public void Tutorial(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tutorialspoint.com/computer_organization/index.asp"));
        startActivity(C);

    }

    public void rateProf(View view) {
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ratemyprofessors.com/campusRatings.jsp?sid=4134"));
        startActivity(C);

    }

    public void quizzes(View view){
        Intent C = new Intent(Intent.ACTION_VIEW, Uri.parse("https://quizlet.com/396292849/introduction-to-computer-organization-flash-cards/"));
        startActivity(C);

    }


    public void browser1(View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.uhd.edu/myuhd/Pages/Student-Login.aspx"));
        startActivity(browserIntent);
    }

    public void feedback(View view){
        Intent Open6Intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://docs.google.com/forms/d/e/1FAIpQLSe1IqRWZKl9tPNaJhCl0Fpl8mJgpUSwtREJPqNfo34eeoFrqQ/viewform?vc=0&c=0&w=1"));
        startActivity(Open6Intent);

    }

    public void home(View view){
        Intent browserIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(browserIntent);

    }



}